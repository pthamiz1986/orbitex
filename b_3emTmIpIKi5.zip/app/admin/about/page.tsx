'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { isAuthenticated } from '@/lib/admin-auth'
import { createClient } from '@/lib/supabase/client'

interface AboutContent {
  id: string
  company_story: string
  mission: string
  vision: string
  years_experience: number
  projects_completed: number
  team_members: number
}

export default function AboutEditor() {
  const router = useRouter()
  const [isAuthed, setIsAuthed] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [content, setContent] = useState<AboutContent | null>(null)

  useEffect(() => {
    if (!isAuthenticated()) {
      router.push('/admin/login')
    } else {
      setIsAuthed(true)
      loadContent()
    }
  }, [router])

  const loadContent = async () => {
    try {
      const supabase = createClient()
      let { data, error: err } = await supabase
        .from('about_content')
        .select('*')
        .single()

      if (err && err.code === 'PGRST116') {
        // No data exists, insert default
        const { data: inserted, error: insertErr } = await supabase
          .from('about_content')
          .insert({
            company_story: 'ORBITEX is a leading provider of geospatial solutions...',
            mission: 'To deliver cutting-edge geospatial data and expertise...',
            vision: 'To be the trusted partner for enterprise geospatial solutions...',
            years_experience: 10,
            projects_completed: 150,
            team_members: 25,
          })
          .select()
          .single()

        if (insertErr) throw insertErr
        data = inserted
      } else if (err) throw err

      setContent(data)
    } catch (err) {
      setError('Failed to load content')
      console.log('[v0] Error loading about content:', err)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSave = async () => {
    if (!content) return
    setIsSaving(true)
    setError('')
    setSuccess('')

    try {
      const supabase = createClient()
      const { error: err } = await supabase
        .from('about_content')
        .update({
          company_story: content.company_story,
          mission: content.mission,
          vision: content.vision,
          years_experience: content.years_experience,
          projects_completed: content.projects_completed,
          team_members: content.team_members,
          updated_at: new Date().toISOString(),
        })
        .eq('id', content.id)

      if (err) throw err
      setSuccess('About page updated successfully')
    } catch (err) {
      setError('Failed to save changes')
      console.log('[v0] Error saving about content:', err)
    } finally {
      setIsSaving(false)
    }
  }

  if (!isAuthed || isLoading) return null

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex justify-between items-center">
          <h1 className="text-3xl font-bold">Edit About Page</h1>
          <Link href="/admin/dashboard">
            <Button variant="outline">Back</Button>
          </Link>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {error && (
          <Alert className="mb-6 border-destructive bg-destructive/10">
            <AlertDescription className="text-destructive">{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mb-6 border-green-500 bg-green-500/10">
            <AlertDescription className="text-green-700">{success}</AlertDescription>
          </Alert>
        )}

        {content && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Company Story</CardTitle>
                <CardDescription>Edit your company&apos;s story</CardDescription>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={content.company_story}
                  onChange={(e) => setContent({ ...content, company_story: e.target.value })}
                  rows={5}
                  className="w-full"
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Mission</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={content.mission}
                  onChange={(e) => setContent({ ...content, mission: e.target.value })}
                  rows={4}
                  className="w-full"
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Vision</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={content.vision}
                  onChange={(e) => setContent({ ...content, vision: e.target.value })}
                  rows={4}
                  className="w-full"
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Company Statistics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <label className="text-sm font-medium">Years of Experience</label>
                  <Input
                    type="number"
                    value={content.years_experience}
                    onChange={(e) => setContent({ ...content, years_experience: parseInt(e.target.value) })}
                    className="mt-2"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">Projects Completed</label>
                  <Input
                    type="number"
                    value={content.projects_completed}
                    onChange={(e) => setContent({ ...content, projects_completed: parseInt(e.target.value) })}
                    className="mt-2"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">Team Members</label>
                  <Input
                    type="number"
                    value={content.team_members}
                    onChange={(e) => setContent({ ...content, team_members: parseInt(e.target.value) })}
                    className="mt-2"
                  />
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={handleSave}
              disabled={isSaving}
              className="w-full"
              size="lg"
            >
              {isSaving ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
