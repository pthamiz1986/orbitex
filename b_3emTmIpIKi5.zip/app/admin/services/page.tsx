'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { isAuthenticated } from '@/lib/admin-auth'
import { createClient } from '@/lib/supabase/client'

interface Service {
  id: string
  name: string
  description: string
  icon_name: string
  features: string[]
  capabilities: string[]
  display_order: number
}

export default function ServicesEditor() {
  const router = useRouter()
  const [isAuthed, setIsAuthed] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [services, setServices] = useState<Service[]>([])
  const [editingId, setEditingId] = useState<string | null>(null)

  useEffect(() => {
    if (!isAuthenticated()) {
      router.push('/admin/login')
    } else {
      setIsAuthed(true)
      loadServices()
    }
  }, [router])

  const loadServices = async () => {
    try {
      const supabase = createClient()
      const { data, error: err } = await supabase
        .from('services')
        .select('*')
        .order('display_order', { ascending: true })

      if (err) throw err
      setServices(data || [])
    } catch (err) {
      setError('Failed to load services')
      console.log('[v0] Error loading services:', err)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSave = async (service: Service) => {
    setIsSaving(true)
    setError('')
    setSuccess('')

    try {
      const supabase = createClient()
      const { error: err } = await supabase
        .from('services')
        .update({
          name: service.name,
          description: service.description,
          icon_name: service.icon_name,
          features: service.features,
          capabilities: service.capabilities,
          updated_at: new Date().toISOString(),
        })
        .eq('id', service.id)

      if (err) throw err
      setSuccess('Service updated successfully')
      setEditingId(null)
    } catch (err) {
      setError('Failed to save changes')
      console.log('[v0] Error saving service:', err)
    } finally {
      setIsSaving(false)
    }
  }

  const handleUpdateService = (id: string, field: string, value: any) => {
    setServices(services.map(s =>
      s.id === id ? { ...s, [field]: value } : s
    ))
  }

  if (!isAuthed || isLoading) return null

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex justify-between items-center">
          <h1 className="text-3xl font-bold">Manage Services</h1>
          <Link href="/admin/dashboard">
            <Button variant="outline">Back</Button>
          </Link>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {error && (
          <Alert className="mb-6 border-destructive bg-destructive/10">
            <AlertDescription className="text-destructive">{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mb-6 border-green-500 bg-green-500/10">
            <AlertDescription className="text-green-700">{success}</AlertDescription>
          </Alert>
        )}

        <div className="space-y-6">
          {services.map((service) => (
            <Card key={service.id}>
              <CardHeader>
                <CardTitle>{service.name}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Service Name</label>
                  <Input
                    value={service.name}
                    onChange={(e) => handleUpdateService(service.id, 'name', e.target.value)}
                    disabled={editingId !== service.id && editingId !== null}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Description</label>
                  <Textarea
                    value={service.description}
                    onChange={(e) => handleUpdateService(service.id, 'description', e.target.value)}
                    disabled={editingId !== service.id && editingId !== null}
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Icon Name (e.g., Building2, Map, Scan)</label>
                  <Input
                    value={service.icon_name}
                    onChange={(e) => handleUpdateService(service.id, 'icon_name', e.target.value)}
                    disabled={editingId !== service.id && editingId !== null}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Features (comma-separated)</label>
                  <Textarea
                    value={service.features.join(', ')}
                    onChange={(e) => handleUpdateService(service.id, 'features', e.target.value.split(',').map(f => f.trim()))}
                    disabled={editingId !== service.id && editingId !== null}
                    rows={2}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Capabilities (comma-separated)</label>
                  <Textarea
                    value={service.capabilities.join(', ')}
                    onChange={(e) => handleUpdateService(service.id, 'capabilities', e.target.value.split(',').map(c => c.trim()))}
                    disabled={editingId !== service.id && editingId !== null}
                    rows={2}
                  />
                </div>

                <Button
                  onClick={() => {
                    if (editingId === service.id) {
                      handleSave(service)
                    } else {
                      setEditingId(service.id)
                    }
                  }}
                  disabled={isSaving}
                  className="w-full"
                >
                  {editingId === service.id ? (isSaving ? 'Saving...' : 'Save') : 'Edit'}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
