'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { isAuthenticated } from '@/lib/admin-auth'
import { createClient } from '@/lib/supabase/client'
import { Trash2, Upload } from 'lucide-react'

interface GalleryProject {
  id: string
  title: string
  description: string
  category: string
  image_url: string
  image_name: string
  client_name: string
  year: number
  display_order: number
}

export default function GalleryManager() {
  const router = useRouter()
  const [isAuthed, setIsAuthed] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [isUploading, setIsUploading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [projects, setProjects] = useState<GalleryProject[]>([])
  const [editingId, setEditingId] = useState<string | null>(null)
  const [showAddForm, setShowAddForm] = useState(false)
  const [newProject, setNewProject] = useState<Partial<GalleryProject>>({
    title: '',
    description: '',
    category: 'BIM',
    image_url: '',
    client_name: '',
    year: new Date().getFullYear(),
  })

  useEffect(() => {
    if (!isAuthenticated()) {
      router.push('/admin/login')
    } else {
      setIsAuthed(true)
      loadProjects()
    }
  }, [router])

  const loadProjects = async () => {
    try {
      const supabase = createClient()
      const { data, error: err } = await supabase
        .from('gallery_projects')
        .select('*')
        .order('display_order', { ascending: true })

      if (err) throw err
      setProjects(data || [])
    } catch (err) {
      setError('Failed to load projects')
      console.log('[v0] Error loading gallery:', err)
    } finally {
      setIsLoading(false)
    }
  }

  const handleImageUpload = async (file: File, isNew: boolean = false) => {
    setIsUploading(true)
    try {
      const formData = new FormData()
      formData.append('file', file)

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      })

      const data = await response.json()
      if (!response.ok) throw new Error(data.error)

      if (isNew) {
        setNewProject({ ...newProject, image_url: data.url, image_name: data.filename })
      }

      setSuccess('Image uploaded successfully')
    } catch (err) {
      setError('Failed to upload image')
      console.log('[v0] Error uploading image:', err)
    } finally {
      setIsUploading(false)
    }
  }

  const handleAddProject = async () => {
    if (!newProject.title || !newProject.image_url) {
      setError('Please fill in all required fields and upload an image')
      return
    }

    setIsSaving(true)
    setError('')
    setSuccess('')

    try {
      const supabase = createClient()
      const { error: err } = await supabase
        .from('gallery_projects')
        .insert({
          title: newProject.title,
          description: newProject.description || '',
          category: newProject.category || 'BIM',
          image_url: newProject.image_url,
          image_name: newProject.image_name,
          client_name: newProject.client_name || '',
          year: newProject.year || new Date().getFullYear(),
          display_order: projects.length + 1,
        })

      if (err) throw err
      setSuccess('Project added successfully')
      setNewProject({ title: '', description: '', category: 'BIM', image_url: '', client_name: '', year: new Date().getFullYear() })
      setShowAddForm(false)
      loadProjects()
    } catch (err) {
      setError('Failed to add project')
      console.log('[v0] Error adding project:', err)
    } finally {
      setIsSaving(false)
    }
  }

  const handleDeleteProject = async (id: string) => {
    if (!confirm('Are you sure you want to delete this project?')) return

    try {
      const supabase = createClient()
      const { error: err } = await supabase
        .from('gallery_projects')
        .delete()
        .eq('id', id)

      if (err) throw err
      setSuccess('Project deleted successfully')
      loadProjects()
    } catch (err) {
      setError('Failed to delete project')
      console.log('[v0] Error deleting project:', err)
    }
  }

  if (!isAuthed || isLoading) return null

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex justify-between items-center">
          <h1 className="text-3xl font-bold">Manage Gallery</h1>
          <Link href="/admin/dashboard">
            <Button variant="outline">Back</Button>
          </Link>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {error && (
          <Alert className="mb-6 border-destructive bg-destructive/10">
            <AlertDescription className="text-destructive">{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mb-6 border-green-500 bg-green-500/10">
            <AlertDescription className="text-green-700">{success}</AlertDescription>
          </Alert>
        )}

        {/* Add Project Button */}
        <div className="mb-8">
          <Button
            onClick={() => setShowAddForm(!showAddForm)}
            className="w-full"
            size="lg"
          >
            {showAddForm ? 'Cancel' : '+ Add New Project'}
          </Button>
        </div>

        {/* Add Project Form */}
        {showAddForm && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Add New Project</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium">Project Image *</label>
                <div className="border-2 border-dashed border-border rounded-lg p-6">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0]
                      if (file) handleImageUpload(file, true)
                    }}
                    disabled={isUploading}
                    className="w-full"
                  />
                </div>
                {newProject.image_url && (
                  <div className="mt-4 relative w-full h-48">
                    <Image
                      src={newProject.image_url}
                      alt="Preview"
                      fill
                      className="object-cover rounded-lg"
                    />
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Project Title *</label>
                <Input
                  value={newProject.title}
                  onChange={(e) => setNewProject({ ...newProject, title: e.target.value })}
                  placeholder="Enter project title"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Description</label>
                <Textarea
                  value={newProject.description}
                  onChange={(e) => setNewProject({ ...newProject, description: e.target.value })}
                  placeholder="Enter project description"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Category</label>
                  <select
                    value={newProject.category}
                    onChange={(e) => setNewProject({ ...newProject, category: e.target.value })}
                    className="w-full px-3 py-2 border border-border rounded-md bg-background"
                  >
                    <option value="BIM">BIM</option>
                    <option value="GIS">GIS</option>
                    <option value="Scanning">Scanning</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Year</label>
                  <Input
                    type="number"
                    value={newProject.year}
                    onChange={(e) => setNewProject({ ...newProject, year: parseInt(e.target.value) })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Client Name</label>
                <Input
                  value={newProject.client_name}
                  onChange={(e) => setNewProject({ ...newProject, client_name: e.target.value })}
                  placeholder="Enter client name"
                />
              </div>

              <Button
                onClick={handleAddProject}
                disabled={isSaving || isUploading}
                className="w-full"
              >
                {isSaving ? 'Adding...' : 'Add Project'}
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {projects.map((project) => (
            <Card key={project.id} className="overflow-hidden">
              <div className="relative w-full h-48 bg-muted">
                <Image
                  src={project.image_url}
                  alt={project.title}
                  fill
                  className="object-cover"
                />
              </div>
              <CardContent className="p-6 space-y-4">
                <div>
                  <h3 className="font-semibold text-lg">{project.title}</h3>
                  <p className="text-sm text-muted-foreground">{project.category} • {project.year}</p>
                </div>
                <p className="text-sm text-foreground/80">{project.description}</p>
                {project.client_name && (
                  <p className="text-sm text-muted-foreground">Client: {project.client_name}</p>
                )}
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => handleDeleteProject(project.id)}
                  className="w-full"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
