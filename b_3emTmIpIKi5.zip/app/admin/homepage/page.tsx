'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { isAuthenticated } from '@/lib/admin-auth'
import { createClient } from '@/lib/supabase/client'

interface HomepageContent {
  id: string
  hero_title: string
  hero_subtitle: string
  hero_description: string
  cta_text: string
  cta_link: string
}

export default function HomepageEditor() {
  const router = useRouter()
  const [isAuthed, setIsAuthed] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [content, setContent] = useState<HomepageContent | null>(null)

  useEffect(() => {
    if (!isAuthenticated()) {
      router.push('/admin/login')
    } else {
      setIsAuthed(true)
      loadContent()
    }
  }, [router])

  const loadContent = async () => {
    try {
      const supabase = createClient()
      const { data, error: err } = await supabase
        .from('homepage_content')
        .select('*')
        .single()

      if (err) throw err
      setContent(data)
    } catch (err) {
      setError('Failed to load content')
      console.log('[v0] Error loading homepage content:', err)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSave = async () => {
    if (!content) return
    setIsSaving(true)
    setError('')
    setSuccess('')

    try {
      const supabase = createClient()
      const { error: err } = await supabase
        .from('homepage_content')
        .update({
          hero_title: content.hero_title,
          hero_subtitle: content.hero_subtitle,
          hero_description: content.hero_description,
          cta_text: content.cta_text,
          cta_link: content.cta_link,
          updated_at: new Date().toISOString(),
        })
        .eq('id', content.id)

      if (err) throw err
      setSuccess('Homepage updated successfully')
    } catch (err) {
      setError('Failed to save changes')
      console.log('[v0] Error saving homepage:', err)
    } finally {
      setIsSaving(false)
    }
  }

  if (!isAuthed || isLoading) return null

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex justify-between items-center">
          <h1 className="text-3xl font-bold">Edit Homepage</h1>
          <Link href="/admin/dashboard">
            <Button variant="outline">Back</Button>
          </Link>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {error && (
          <Alert className="mb-6 border-destructive bg-destructive/10">
            <AlertDescription className="text-destructive">{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mb-6 border-green-500 bg-green-500/10">
            <AlertDescription className="text-green-700">{success}</AlertDescription>
          </Alert>
        )}

        {content && (
          <Card>
            <CardHeader>
              <CardTitle>Hero Section</CardTitle>
              <CardDescription>Edit your homepage hero content</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium">Hero Title</label>
                <Input
                  value={content.hero_title}
                  onChange={(e) => setContent({ ...content, hero_title: e.target.value })}
                  placeholder="Enter hero title"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Hero Subtitle</label>
                <Input
                  value={content.hero_subtitle}
                  onChange={(e) => setContent({ ...content, hero_subtitle: e.target.value })}
                  placeholder="Enter hero subtitle"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Hero Description</label>
                <Textarea
                  value={content.hero_description}
                  onChange={(e) => setContent({ ...content, hero_description: e.target.value })}
                  placeholder="Enter hero description"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">CTA Text</label>
                  <Input
                    value={content.cta_text}
                    onChange={(e) => setContent({ ...content, cta_text: e.target.value })}
                    placeholder="Button text"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">CTA Link</label>
                  <Input
                    value={content.cta_link}
                    onChange={(e) => setContent({ ...content, cta_link: e.target.value })}
                    placeholder="/services"
                  />
                </div>
              </div>

              <Button
                onClick={handleSave}
                disabled={isSaving}
                className="w-full"
              >
                {isSaving ? 'Saving...' : 'Save Changes'}
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
