'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { isAuthenticated } from '@/lib/admin-auth'
import { createClient } from '@/lib/supabase/client'
import { Trash2, Plus } from 'lucide-react'

interface TrainingCourse {
  id: string
  title: string
  description: string
  duration: string
  level: string
  price: number
  curriculum: string[]
  prerequisites: string
  instructor_name: string
  display_order: number
}

export default function TrainingManager() {
  const router = useRouter()
  const [isAuthed, setIsAuthed] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [courses, setCourses] = useState<TrainingCourse[]>([])
  const [editingId, setEditingId] = useState<string | null>(null)
  const [showAddForm, setShowAddForm] = useState(false)
  const [newCourse, setNewCourse] = useState<Partial<TrainingCourse>>({
    title: '',
    description: '',
    duration: '',
    level: 'Intermediate',
    price: 0,
    curriculum: [],
    prerequisites: '',
    instructor_name: '',
  })

  useEffect(() => {
    if (!isAuthenticated()) {
      router.push('/admin/login')
    } else {
      setIsAuthed(true)
      loadCourses()
    }
  }, [router])

  const loadCourses = async () => {
    try {
      const supabase = createClient()
      const { data, error: err } = await supabase
        .from('training_courses')
        .select('*')
        .order('display_order', { ascending: true })

      if (err) throw err
      setCourses(data || [])
    } catch (err) {
      setError('Failed to load courses')
      console.log('[v0] Error loading training courses:', err)
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddCourse = async () => {
    if (!newCourse.title || !newCourse.description || !newCourse.duration) {
      setError('Please fill in all required fields')
      return
    }

    setIsSaving(true)
    setError('')
    setSuccess('')

    try {
      const supabase = createClient()
      const { error: err } = await supabase
        .from('training_courses')
        .insert({
          title: newCourse.title,
          description: newCourse.description,
          duration: newCourse.duration,
          level: newCourse.level || 'Intermediate',
          price: newCourse.price || 0,
          curriculum: newCourse.curriculum || [],
          prerequisites: newCourse.prerequisites || '',
          instructor_name: newCourse.instructor_name || '',
          display_order: courses.length + 1,
        })

      if (err) throw err
      setSuccess('Course added successfully')
      setNewCourse({
        title: '',
        description: '',
        duration: '',
        level: 'Intermediate',
        price: 0,
        curriculum: [],
        prerequisites: '',
        instructor_name: '',
      })
      setShowAddForm(false)
      loadCourses()
    } catch (err) {
      setError('Failed to add course')
      console.log('[v0] Error adding course:', err)
    } finally {
      setIsSaving(false)
    }
  }

  const handleUpdateCourse = async (course: TrainingCourse) => {
    setIsSaving(true)
    setError('')
    setSuccess('')

    try {
      const supabase = createClient()
      const { error: err } = await supabase
        .from('training_courses')
        .update({
          title: course.title,
          description: course.description,
          duration: course.duration,
          level: course.level,
          price: course.price,
          curriculum: course.curriculum,
          prerequisites: course.prerequisites,
          instructor_name: course.instructor_name,
          updated_at: new Date().toISOString(),
        })
        .eq('id', course.id)

      if (err) throw err
      setSuccess('Course updated successfully')
      setEditingId(null)
    } catch (err) {
      setError('Failed to save changes')
      console.log('[v0] Error updating course:', err)
    } finally {
      setIsSaving(false)
    }
  }

  const handleDeleteCourse = async (id: string) => {
    if (!confirm('Are you sure you want to delete this course?')) return

    try {
      const supabase = createClient()
      const { error: err } = await supabase
        .from('training_courses')
        .delete()
        .eq('id', id)

      if (err) throw err
      setSuccess('Course deleted successfully')
      loadCourses()
    } catch (err) {
      setError('Failed to delete course')
      console.log('[v0] Error deleting course:', err)
    }
  }

  const handleUpdateCourseField = (id: string, field: string, value: any) => {
    setCourses(courses.map(c =>
      c.id === id ? { ...c, [field]: value } : c
    ))
  }

  if (!isAuthed || isLoading) return null

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex justify-between items-center">
          <h1 className="text-3xl font-bold">Manage Training Courses</h1>
          <Link href="/admin/dashboard">
            <Button variant="outline">Back</Button>
          </Link>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {error && (
          <Alert className="mb-6 border-destructive bg-destructive/10">
            <AlertDescription className="text-destructive">{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mb-6 border-green-500 bg-green-500/10">
            <AlertDescription className="text-green-700">{success}</AlertDescription>
          </Alert>
        )}

        {/* Add Course Button */}
        <div className="mb-8">
          <Button
            onClick={() => setShowAddForm(!showAddForm)}
            className="w-full"
            size="lg"
          >
            {showAddForm ? 'Cancel' : '+ Add New Course'}
          </Button>
        </div>

        {/* Add Course Form */}
        {showAddForm && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Add New Course</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium">Course Title *</label>
                <Input
                  value={newCourse.title}
                  onChange={(e) => setNewCourse({ ...newCourse, title: e.target.value })}
                  placeholder="Enter course title"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Description *</label>
                <Textarea
                  value={newCourse.description}
                  onChange={(e) => setNewCourse({ ...newCourse, description: e.target.value })}
                  placeholder="Enter course description"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Duration *</label>
                  <Input
                    value={newCourse.duration}
                    onChange={(e) => setNewCourse({ ...newCourse, duration: e.target.value })}
                    placeholder="e.g., 4 weeks"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Level</label>
                  <select
                    value={newCourse.level}
                    onChange={(e) => setNewCourse({ ...newCourse, level: e.target.value })}
                    className="w-full px-3 py-2 border border-border rounded-md bg-background"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Price</label>
                  <Input
                    type="number"
                    value={newCourse.price}
                    onChange={(e) => setNewCourse({ ...newCourse, price: parseFloat(e.target.value) })}
                    placeholder="0.00"
                    step="0.01"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Instructor Name</label>
                  <Input
                    value={newCourse.instructor_name}
                    onChange={(e) => setNewCourse({ ...newCourse, instructor_name: e.target.value })}
                    placeholder="Enter instructor name"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Prerequisites</label>
                <Textarea
                  value={newCourse.prerequisites}
                  onChange={(e) => setNewCourse({ ...newCourse, prerequisites: e.target.value })}
                  placeholder="Enter prerequisites"
                  rows={2}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Curriculum (comma-separated)</label>
                <Textarea
                  value={newCourse.curriculum?.join(', ')}
                  onChange={(e) => setNewCourse({ ...newCourse, curriculum: e.target.value.split(',').map(c => c.trim()) })}
                  placeholder="Module 1, Module 2, Module 3"
                  rows={3}
                />
              </div>

              <Button
                onClick={handleAddCourse}
                disabled={isSaving}
                className="w-full"
              >
                {isSaving ? 'Adding...' : 'Add Course'}
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Courses List */}
        <div className="space-y-6">
          {courses.map((course) => (
            <Card key={course.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{course.title}</CardTitle>
                    <CardDescription>{course.level} • {course.duration}</CardDescription>
                  </div>
                  {editingId !== course.id && (
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDeleteCourse(course.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Description</label>
                  <Textarea
                    value={course.description}
                    onChange={(e) => handleUpdateCourseField(course.id, 'description', e.target.value)}
                    disabled={editingId !== course.id && editingId !== null}
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Price</label>
                    <Input
                      type="number"
                      value={course.price}
                      onChange={(e) => handleUpdateCourseField(course.id, 'price', parseFloat(e.target.value))}
                      disabled={editingId !== course.id && editingId !== null}
                      step="0.01"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Instructor</label>
                    <Input
                      value={course.instructor_name}
                      onChange={(e) => handleUpdateCourseField(course.id, 'instructor_name', e.target.value)}
                      disabled={editingId !== course.id && editingId !== null}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Curriculum</label>
                  <Textarea
                    value={course.curriculum.join(', ')}
                    onChange={(e) => handleUpdateCourseField(course.id, 'curriculum', e.target.value.split(',').map(c => c.trim()))}
                    disabled={editingId !== course.id && editingId !== null}
                    rows={3}
                  />
                </div>

                <Button
                  onClick={() => {
                    if (editingId === course.id) {
                      handleUpdateCourse(course)
                    } else {
                      setEditingId(course.id)
                    }
                  }}
                  disabled={isSaving}
                  className="w-full"
                >
                  {editingId === course.id ? (isSaving ? 'Saving...' : 'Save') : 'Edit'}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
